<link rel="stylesheet" type="text/css" href="Lojainformatica.css">
    
    <input type="button" value="Login"  onclick="mostra('ma')"/>


<!--criando botão que esconde o formulario-->

<style type="text/css">
    	
    	.hidden{
    		display: none;
    	}

    	input{
    		display: block;
    		background: rgba(255,250,250);
    		float: right;
    		color: black;
		    font-weight: bold; 
		    padding: 3px 5px;
		    border: none; 
		    border-radius: 4px; 
		   cursor: pointer;

    	}

    </style>

    <script type="text/javascript">
    	
    	function mostra(id){
if (document.getElementById(id).style.display == 'block'){
	document.getElementById(id).style.display = 'none';
} else {document.getElementById(id).style.display = 'block'}

    	}
    </script>

    <script type="text/javascript">
		
		function abrir() {
			var menu = document.getElementById("menu");
			menu.style.width = "260px";
		}

		function fechar() {
			var menu = document.getElementById("menu");
			menu.style.width = "0px";
		}

	</script>

<!--fim o botão-->

</head>

<body>


	<div class="topo"> 

		<div class="textotopo"><h1>Loja de informatica</h1></div>



		
		<form>
<!--criando formulario-->

<div id="ma" class="hidden"> 
	<div class="formulario">

	<div class="grid">


		
		<h4>Aréa</h4>

		<h4> do cliente</h4> 
	

	 <tr>

        <td>CPF: </td><td><input type="text" name="campo_cpf" placeholder="CPF"  id="cmpCpf"></td>

         </tr>

             <tr>
 
               <td>Senha: </td><td><input type="password" name="campo_senha" placeholder="Senha" id="cmpSn"></td>

            </tr>

      </div>

     <input type="submit" name="submit" value="envia">

     <input type="reset" name="reset" value="limpar">



	</form>	

	</div>

	</div>

<!-- fim do formulario-->


</div><!--fim da div topo-->


<script type="text/javascript">
	function caixa_alta(tag){
		tag.value = tag.value.toUppercase();
	}
</script>


<div  id="menu" class="menu">

    <a href="index.php">Home</a>
    <a href="laptop_form.html">Laptop</a>
    <a href="desktop_form.html">desktop</a>
	<a href="print_form.html">Impressoras</a>	
	<a href="cliente_form.html">Cliente</a>
	<a href="venda_form.php">Venda</a>
    <a href="funcionario_form.html">Funcionários</a>
    <a href="acessorestrito.php">Acesso Restrito</a>


     <input type="search" placeholder="pesquisar produtos..." class="pesquisa">
</div>

<img src="gg.png" width="100%" height="320px">

<script src="jquery-3.5.1.min.js"></script>
    <script src="scripts.js"></script>
</head>
<body>
<div>
    <h1>INSERIR VENDA</h1>
    <form id="formVenda" method="post">
        <table>
            <tr>
                <td>Cliente: </td><td>
                    <select name="campo_nome" id="cmpNm">
                        <option value="#">Selecione...</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Funcionário: </td><td>
                    <select name="campo_funcionario" id="cmpFuncionario">
                            <option value="#">Selecione...</option>
                    </select>
                </td>   
            </tr>
            <tr>
                <td>Desktop: </td><td>
                <select name="campo_desktop" id="cmpAnimal">
                        <option value="#">Selecione...</option>
                </select>
                </td>   
            </tr>
            <tr>
                <td>Data da venda: </td><td><input type="text" name="campo_dataVenda" id="cmpDv"></td>                
            </tr>
            <tr>
                <td>Preço: </td><td><input type="text" name="campo_preco" id="cmpPrc"></td>
            </tr>
            <tr>
                <td><input type="submit" value="SALVAR"></td><td></td>
            </tr>
        </table>
    </form>
</div>