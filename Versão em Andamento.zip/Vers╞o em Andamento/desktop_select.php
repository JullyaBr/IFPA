<?php
    $sql = "SELECT * FROM desktop";
    include "conexao.php";
    $resposta = "<option value='#'>Selecione...</option>";
    if($resultado = mysqli_query($con,$sql)){
        while($lh = mysqli_fetch_assoc($resultado)){
            $resposta .= "<option value='".$lh['id']."'>".$lh['fabricante']." ".Processador." ".$lh['cpu']." ".$lh['ram']."  ".RAM."  ".$lh['hd']." ".HD."</option>";
        }
        echo $resposta;
    }
?>