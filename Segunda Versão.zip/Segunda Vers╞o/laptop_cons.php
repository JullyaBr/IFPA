<button id="btn_bsc_Laptop">Preencher</button><br>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>FABRICANTE</th>
            <th>PROCESSADOR</th>
            <th>MEMORIA RAM</th>
            <th>DISCO RIGIDO</th>
            <th>TELA</th>
            <th>PREÇO</th>
        </tr>
    </thead>
    <tbody id="tbl_Laptop">

    </tbody>
</table>